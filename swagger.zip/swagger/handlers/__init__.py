"""User and administrative routers."""
